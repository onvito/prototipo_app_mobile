import React from 'react';
import { FlatList, Pressable, SafeAreaView, Text, View, ImageBackground, StyleSheet } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { AntDesign } from '@expo/vector-icons';

const image = { uri: "https://images.cdn4.stockunlimited.net/preview1300/cinema-background-with-movie-objects_1823382.jpg" };

export default function Lista({ navigation }) {
  const contatinhos = [
    { nome: 'The Batman', lancamento: '04/04/2022' },
    { nome: 'Sonic 2', lancamento: '05/05/2022' },
    { nome: 'Doctor Strange 2', lancamento: '06/06/2022' },
  ];
  const Contato = ({ item }) => {
    return (
      <View
        style={styles.container}>     
        <Text style={{ flex: 2, color: 'black' }}>{item.nome}</Text>
        <Text style={{ flex: 1, color: 'black' }}>{item.lancamento}</Text>   
      </View>      
    );
  };
  return (
    <ImageBackground source={image} style={styles.image}>
    <SafeAreaView style={{flex :1}}>
    
    <View style={{flex :1}}>
       <View style={styles.titulo}>
          <Text
            style={{ flex: 2,
              color: 'white',
              fontSize: 24,
            }}>
            Filmes Favoritos
          </Text>
          <Pressable onPress={() => navigation.goBack()}>
          <Text style={{color: 'white'}}>SAIR</Text>
          </Pressable>
      </View>
      
      <FlatList data={contatinhos} renderItem={Contato} />
      <Pressable 
      style={styles.adding}
      onPress={() => navigation.navigate('cadastro')}>
        <Text style={{color: 'white', fontSize: 24}}>+</Text>
      </Pressable>
    </View>
    </SafeAreaView>
        </ImageBackground>

  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: 56,
    borderBottomColor: 'lightgrey',
    borderBottomWidth: 1,
    backgroundColor: 'white'
  },
  image: {
    flex: 1,
    justifyContent: "center",
  },

  titulo: {
          flexDirection: 'row',
          paddingLeft: 16,
          backgroundColor: 'black',
          height: 56,
          alignItems: 'center'
  },
  
  adding: {
    position: 'absolute', 
    bottom: 56, 
    right: 15, 
    height: 48, 
    width: 48, 
    backgroundColor: 'darkred', 
    borderRadius: 40, 
    justifyContent: 'center', 
    alignItems: 'center'
  }

});