import React from 'react';
import { View, Text, TextInput, Button, ImageBackground, StyleSheet, SafeAreaView, Pressable } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const image = { uri: "https://images.cdn4.stockunlimited.net/preview1300/cinema-background-with-movie-objects_1823382.jpg" };

export default function Login({ navigation }) {
  return (
    <SafeAreaView
      style={styles.container}>
    <ImageBackground source={image} style={styles.image}>
    
      <Text style={styles.logo}>
        <MaterialIcons name="local-movies" size={72} color="lightgrey" />
      </Text>

      <Text style={styles.titulo}>
        Filmaços
      </Text>

      <Text style={styles.rotulo}> Email</Text>
      <TextInput
        style={styles.input}
        keyboardType='email-address'
      />

      <Text style={styles.rotulo}> Senha </Text>
      <TextInput 
        style={styles.input}
        secureTextEntry={true}
      />

      <View style={{paddingTop: 24}}>

      <Pressable onPress={() => navigation.navigate('lista')}>
          <Text style={styles.entrar}>Entrar</Text>
      </Pressable>

 
      </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    
  },
  image: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 16
  },

  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'lightgrey'
  },

  logo: {
    fontSize: 72,
    fontWeight: 'bold',
    
    textAlign: 'center',
  },

  input: {
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
  },

   rotulo: { 
    color: 'lightgrey', 
    paddingTop: 16 
  },

  entrar: {
    padding: 20,
    margin: 10,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#f0f0f0',
    backgroundColor: 'darkred',
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center'
  }
});

