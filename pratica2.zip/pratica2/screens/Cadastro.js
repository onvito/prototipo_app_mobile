import React from 'react';
import { StyleSheet, Text, TextInput, View, Button, Pressable, SafeAreaView } from 'react-native';
import { AntDesign } from '@expo/vector-icons';

export default function Cadastro({ navigation }) {
  return (
    <SafeAreaView >
      <View style={{ flex: 1}}>
        <View style={styles.titulo}>
          <Text
            style={{ flex: 2,
              color: 'white',
              fontSize: 24,}}>
              <AntDesign 
              name="caretleft" 
              size={24} 
              color="white" 
              onPress={() => navigation.navigate('lista')}/>
              Novo Filme
          </Text>
            <Pressable onPress={() => navigation.goBack()}>
              <Text style={{color: 'white'}}>Salvar</Text>
            </Pressable>
        </View>
      
      <View style={{ paddingHorizontal: 16}}>
        <Text style={styles.rotulo}>Nome</Text>
          <TextInput style={styles.input}
            keyboardType="name-phone-pad"
          />
        <Text style={styles.rotulo}>Data de Lançamento</Text>
          <TextInput style={styles.input}
            keyboardType="number-pad"
          />
      <View style={{paddingTop: 24}}>
      
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({  
  rotulo: { 
    color: 'grey', 
    paddingTop: 16 
  },
  input: {
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
  },

  titulo: {
    paddingLeft: 16,
    backgroundColor: 'black',
    color: 'white',
    height: 56,
    fontSize: 24,
    paddingVertical: 16,

    flexDirection: 'row',
    paddingTop: 16,
    alignItems: 'center'
  }
});